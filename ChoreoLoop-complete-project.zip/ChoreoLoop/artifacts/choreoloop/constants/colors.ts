/**
 * Semantic design tokens for the mobile app.
 *
 * These tokens mirror the naming conventions used in web artifacts (index.css)
 * so that multi-artifact projects share a cohesive visual identity.
 *
 * Replace the placeholder values below with values that match the project's
 * brand. If a sibling web artifact exists, read its index.css and convert the
 * HSL values to hex so both artifacts use the same palette.
 *
 * To add dark mode, add a `dark` key with the same token names.
 * The useColors() hook will automatically pick it up.
 */

const colors = {
  light: {
    // Legacy aliases (kept for backward compatibility)
    text: '#1B1C2A',
    tint: '#EF5B4F',

    // Core surfaces
    background: '#F8F4EE',
    foreground: '#1B1C2A',

    // Cards / elevated surfaces
    card: '#FFFFFF',
    cardForeground: '#1B1C2A',

    // Primary action color (buttons, links, active states)
    primary: '#EF5B4F',
    primaryForeground: '#ffffff',

    // Secondary / less-emphasis interactive surfaces
    secondary: '#E6EBDD',
    secondaryForeground: '#1B1C2A',

    // Muted / subdued elements (dividers, timestamps, placeholders)
    muted: '#EDE8E1',
    mutedForeground: '#77736F',

    // Accent highlights (badges, selected items, focus rings)
    accent: '#F7D9BF',
    accentForeground: '#1B1C2A',

    // Destructive actions (delete, error states)
    destructive: '#D83F50',
    destructiveForeground: '#ffffff',

    // Borders and input outlines
    border: '#E6E0D9',
    input: '#E6E0D9',
  },

  dark: {
    text: '#F8F4EE',
    tint: '#FF806F',
    background: '#191A28',
    foreground: '#F8F4EE',
    card: '#242638',
    cardForeground: '#F8F4EE',
    primary: '#FF806F',
    primaryForeground: '#191A28',
    secondary: '#313A35',
    secondaryForeground: '#F8F4EE',
    muted: '#2B2C3D',
    mutedForeground: '#B8B3AC',
    accent: '#5B413B',
    accentForeground: '#F8F4EE',
    destructive: '#F16B78',
    destructiveForeground: '#191A28',
    border: '#393A4C',
    input: '#393A4C',
  },

  // Border radius (in px). Sync from the sibling web artifact's --radius
  // CSS variable. This value applies to cards, buttons, inputs, and modals.
  radius: 18,
};

export default colors;
