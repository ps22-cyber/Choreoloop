import AsyncStorage from '@react-native-async-storage/async-storage';
import { Feather, Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { useLocalSearchParams, useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import React, { useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

const streetCover = require('../assets/images/cover-street.png');
const contemporaryCover = require('../assets/images/cover-contemporary.png');

const steps = [
  { number: '01', label: 'Set the base', detail: 'Ground through your left foot. Keep your chest relaxed.', done: true, cue: 'Weight in the ball of your foot' },
  { number: '02', label: 'Open the groove', detail: 'Let your right shoulder lead before the hips follow.', done: true, cue: 'Shoulder starts the story' },
  { number: '03', label: 'Catch the pause', detail: 'Freeze for half a count, then release into the turn.', done: false, cue: 'Tiny pause — don’t rush it' },
  { number: '04', label: 'Finish the line', detail: 'Complete the shape with a clean arm pathway overhead.', done: false, cue: 'Reach long, not wide' },
];

export default function LearnScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const { id } = useLocalSearchParams<{ id?: string }>();
  const [activeStep, setActiveStep] = useState(2);
  const [showTip, setShowTip] = useState(false);
  const isContemporary = id === 'orbit';
  const cover = isContemporary ? contemporaryCover : streetCover;
  const title = isContemporary ? 'Orbit Sequence' : 'Pulse Control';
  const style = isContemporary ? 'Contemporary' : 'Hip-hop';

  const complete = async () => {
    await AsyncStorage.setItem('choreoloop.practice', JSON.stringify({ completed: true }));
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
    setActiveStep(Math.min(activeStep + 1, steps.length - 1));
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingBottom: insets.bottom + 34 }}>
        <View style={styles.videoWrap}>
          <Image source={cover} style={styles.videoImage} contentFit="cover" />
          <View style={styles.videoShade} />
          <Pressable onPress={() => router.back()} style={[styles.backButton, { top: insets.top + 10 }]} accessibilityRole="button" accessibilityLabel="Go back"><Ionicons name="chevron-back" size={23} color="#FFFFFF" /></Pressable>
          <View style={[styles.videoLabel, { top: insets.top + 14 }]}><View style={styles.sourceDot} /><Text style={styles.videoLabelText}>OFFICIAL SOURCE</Text></View>
          <View style={styles.playButton}><Feather name="play" size={29} color={colors.foreground} /></View>
          <View style={styles.videoBottom}><Text style={styles.videoTime}>0:24 / 0:52</Text><View style={styles.videoTrack}><View style={[styles.videoFill, { backgroundColor: colors.primary }]} /></View><Feather name="volume-2" size={17} color="#FFFFFF" /></View>
        </View>
        <View style={styles.content}>
          <Text style={[styles.kicker, { color: colors.primary }]}>{style.toUpperCase()} · MEMORY LAB</Text>
          <Text style={[styles.title, { color: colors.foreground }]}>{title}</Text>
          <Text style={[styles.subtitle, { color: colors.mutedForeground }]}>Break it down, then make it yours.</Text>

          <View style={[styles.modeRow, { backgroundColor: colors.muted }]}>
            <View style={[styles.modeActive, { backgroundColor: colors.card }]}><Feather name="layers" size={15} color={colors.primary} /><Text style={[styles.modeText, { color: colors.foreground }]}>Step mode</Text></View>
            <View style={styles.modeItem}><Feather name="repeat" size={15} color={colors.mutedForeground} /><Text style={[styles.modeText, { color: colors.mutedForeground }]}>Loop</Text></View>
            <View style={styles.modeItem}><Feather name="clock" size={15} color={colors.mutedForeground} /><Text style={[styles.modeText, { color: colors.mutedForeground }]}>Slow-mo</Text></View>
          </View>

          <View style={styles.stepHeader}><Text style={[styles.stepHeaderText, { color: colors.foreground }]}>Your breakdown</Text><Text style={[styles.stepCount, { color: colors.primary }]}>{activeStep + 1} / {steps.length}</Text></View>
          {steps.map((step, index) => (
            <Pressable key={step.number} onPress={() => setActiveStep(index)} style={[styles.stepRow, { borderColor: index === activeStep ? colors.primary : colors.border, backgroundColor: index === activeStep ? colors.accent : colors.card }]}>
              <View style={[styles.stepNumber, { backgroundColor: step.done ? colors.secondary : index === activeStep ? colors.primary : colors.muted }]}><Text style={[styles.stepNumberText, { color: step.done || index === activeStep ? colors.foreground : colors.mutedForeground }]}>{step.done ? '✓' : step.number}</Text></View>
              <View style={{ flex: 1 }}><Text style={[styles.stepLabel, { color: colors.foreground }]}>{step.label}</Text><Text style={[styles.stepDetail, { color: colors.mutedForeground }]}>{step.detail}</Text></View>
              {index === activeStep && <Feather name="chevron-right" size={18} color={colors.primary} />}
            </Pressable>
          ))}

          <View style={[styles.tipCard, { backgroundColor: colors.foreground }]}>
            <View style={[styles.tipIcon, { backgroundColor: colors.primary }]}><Feather name="eye" size={16} color={colors.primaryForeground} /></View>
            <View style={{ flex: 1 }}><Text style={[styles.tipTitle, { color: colors.background }]}>Visual cue</Text><Text style={[styles.tipText, { color: colors.mutedForeground }]}>{showTip ? steps[activeStep].cue : 'Need help with this step?'}</Text></View>
            <Pressable onPress={() => setShowTip(!showTip)} accessibilityRole="button" accessibilityLabel="Show visual cue"><Text style={[styles.tipAction, { color: colors.primary }]}>{showTip ? 'Hide' : 'Show'}</Text></Pressable>
          </View>
          <Pressable testID="mark-practiced" onPress={complete} style={({ pressed }) => [styles.primaryButton, { backgroundColor: colors.primary, opacity: pressed ? 0.8 : 1 }]} accessibilityRole="button"><Feather name="check" size={18} color={colors.primaryForeground} /><Text style={[styles.primaryButtonText, { color: colors.primaryForeground }]}>Mark step practiced</Text></Pressable>
          <Pressable testID="learn-record" onPress={() => router.push('/record')} style={({ pressed }) => [styles.secondaryButton, { borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]} accessibilityRole="button"><Feather name="video" size={18} color={colors.foreground} /><Text style={[styles.secondaryButtonText, { color: colors.foreground }]}>Record my version</Text></Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  videoWrap: { height: 330, position: 'relative', backgroundColor: '#1B1C2A' },
  videoImage: { ...StyleSheet.absoluteFillObject },
  videoShade: { ...StyleSheet.absoluteFillObject, backgroundColor: 'rgba(18,19,31,0.28)' },
  backButton: { position: 'absolute', left: 17, width: 40, height: 40, borderRadius: 20, backgroundColor: 'rgba(27,28,42,0.45)', alignItems: 'center', justifyContent: 'center' },
  videoLabel: { position: 'absolute', right: 17, backgroundColor: 'rgba(248,244,238,0.9)', paddingHorizontal: 10, paddingVertical: 7, borderRadius: 14, flexDirection: 'row', alignItems: 'center', gap: 5 },
  sourceDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#EF5B4F' },
  videoLabelText: { fontSize: 9, fontWeight: '800', color: '#1B1C2A', letterSpacing: 0.8 },
  playButton: { position: 'absolute', top: '42%', left: '44%', width: 60, height: 60, borderRadius: 30, backgroundColor: '#F8F4EE', alignItems: 'center', justifyContent: 'center', paddingLeft: 4 },
  videoBottom: { position: 'absolute', bottom: 17, left: 17, right: 17, flexDirection: 'row', alignItems: 'center', gap: 10 },
  videoTime: { color: '#FFFFFF', fontSize: 11 },
  videoTrack: { height: 4, backgroundColor: 'rgba(255,255,255,0.35)', flex: 1, borderRadius: 2 },
  videoFill: { height: 4, width: '46%', borderRadius: 2 },
  content: { paddingHorizontal: 22, paddingTop: 25 },
  kicker: { fontSize: 10, fontWeight: '800', letterSpacing: 1.3 },
  title: { fontSize: 30, fontWeight: '700', letterSpacing: -1, marginTop: 5 },
  subtitle: { fontSize: 14, marginTop: 6 },
  modeRow: { marginTop: 24, padding: 4, borderRadius: 14, flexDirection: 'row' },
  modeActive: { borderRadius: 11, flex: 1, paddingVertical: 10, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 5 },
  modeItem: { flex: 1, paddingVertical: 10, flexDirection: 'row', justifyContent: 'center', alignItems: 'center', gap: 5 },
  modeText: { fontSize: 11, fontWeight: '600' },
  stepHeader: { flexDirection: 'row', justifyContent: 'space-between', marginTop: 28, marginBottom: 11 },
  stepHeaderText: { fontSize: 16, fontWeight: '700' },
  stepCount: { fontSize: 12, fontWeight: '700' },
  stepRow: { borderWidth: 1, borderRadius: 16, padding: 12, flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 8 },
  stepNumber: { width: 34, height: 34, borderRadius: 17, alignItems: 'center', justifyContent: 'center' },
  stepNumberText: { fontSize: 11, fontWeight: '800' },
  stepLabel: { fontSize: 13, fontWeight: '700', marginBottom: 3 },
  stepDetail: { fontSize: 11, lineHeight: 16 },
  tipCard: { borderRadius: 17, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 10, marginTop: 16 },
  tipIcon: { width: 32, height: 32, borderRadius: 11, alignItems: 'center', justifyContent: 'center' },
  tipTitle: { fontSize: 12, fontWeight: '700' },
  tipText: { fontSize: 11, marginTop: 2 },
  tipAction: { fontSize: 11, fontWeight: '700' },
  primaryButton: { height: 52, borderRadius: 16, marginTop: 18, flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center' },
  primaryButtonText: { fontSize: 14, fontWeight: '700' },
  secondaryButton: { height: 52, borderRadius: 16, borderWidth: 1, marginTop: 9, flexDirection: 'row', gap: 8, alignItems: 'center', justifyContent: 'center' },
  secondaryButtonText: { fontSize: 14, fontWeight: '700' },
});