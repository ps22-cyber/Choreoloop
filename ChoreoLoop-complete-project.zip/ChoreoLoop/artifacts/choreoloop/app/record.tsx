import AsyncStorage from '@react-native-async-storage/async-storage';
import { Feather, Ionicons } from '@expo/vector-icons';
import * as ImagePicker from 'expo-image-picker';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import React, { useState } from 'react';
import { Alert, Linking, Platform, Pressable, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

export default function RecordScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [takeUri, setTakeUri] = useState<string | null>(null);
  const [isSaving, setIsSaving] = useState(false);

  const saveTake = async (uri: string) => {
    setTakeUri(uri);
    await AsyncStorage.setItem('choreoloop.practice', JSON.stringify({ completed: true, lastTake: uri }));
    await Haptics.notificationAsync(Haptics.NotificationFeedbackType.Success);
  };

  const filmTake = async () => {
    const permission = await ImagePicker.requestCameraPermissionsAsync();
    if (!permission.granted) {
      if (!permission.canAskAgain && Platform.OS !== 'web') {
        Alert.alert('Camera access needed', 'Allow camera access in Settings to film your take.', [{ text: 'Not now', style: 'cancel' }, { text: 'Open Settings', onPress: () => Linking.openSettings() }]);
      } else {
        Alert.alert('Camera access needed', 'ChoreoLoop uses your camera to record your version of the choreography.');
      }
      return;
    }
    setIsSaving(true);
    const result = await ImagePicker.launchCameraAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Videos, videoMaxDuration: 60, quality: 1 });
    setIsSaving(false);
    if (!result.canceled && result.assets[0]?.uri) await saveTake(result.assets[0].uri);
  };

  const chooseTake = async () => {
    const result = await ImagePicker.launchImageLibraryAsync({ mediaTypes: ImagePicker.MediaTypeOptions.Videos, videoMaxDuration: 60, quality: 1 });
    if (!result.canceled && result.assets[0]?.uri) await saveTake(result.assets[0].uri);
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.foreground }]}>
      <View style={[styles.top, { paddingTop: insets.top + 12 }]}>
        <Pressable onPress={() => router.back()} style={styles.iconButton} accessibilityRole="button" accessibilityLabel="Close recording"><Ionicons name="close" size={25} color={colors.background} /></Pressable>
        <Text style={[styles.topTitle, { color: colors.background }]}>Your take</Text>
        <View style={styles.iconButton} />
      </View>
      <View style={styles.center}>
        {takeUri ? (
          <>
            <View style={[styles.successCircle, { backgroundColor: colors.primary }]}><Feather name="check" size={42} color={colors.primaryForeground} /></View>
            <Text style={[styles.centerTitle, { color: colors.background }]}>Take saved</Text>
            <Text style={[styles.centerBody, { color: colors.mutedForeground }]}>Your version is ready for a movement review. Keep practicing the details that make it yours.</Text>
            <Pressable onPress={() => router.push('/profile')} style={({ pressed }) => [styles.reviewButton, { backgroundColor: colors.background, opacity: pressed ? 0.8 : 1 }]} accessibilityRole="button"><Text style={[styles.reviewButtonText, { color: colors.foreground }]}>View my progress</Text><Feather name="arrow-up-right" size={17} color={colors.foreground} /></Pressable>
            <Pressable onPress={filmTake} style={styles.retakeButton} accessibilityRole="button"><Text style={[styles.retakeText, { color: colors.background }]}>Film another take</Text></Pressable>
          </>
        ) : (
          <>
            <View style={styles.cameraGlyph}><Feather name="video" size={38} color={colors.background} /></View>
            <Text style={[styles.centerTitle, { color: colors.background }]}>Make it yours</Text>
            <Text style={[styles.centerBody, { color: colors.mutedForeground }]}>Film up to 60 seconds of your version. We&apos;ll keep it with your practice notes.</Text>
            <Pressable testID="film-take" onPress={filmTake} style={({ pressed }) => [styles.recordButton, { backgroundColor: colors.primary, opacity: pressed || isSaving ? 0.75 : 1 }]} disabled={isSaving} accessibilityRole="button"><View style={styles.recordDot} /><Text style={[styles.recordButtonText, { color: colors.primaryForeground }]}>{isSaving ? 'Opening camera…' : 'Film a take'}</Text></Pressable>
            <Pressable testID="upload-take" onPress={chooseTake} style={({ pressed }) => [styles.uploadButton, { borderColor: colors.border, opacity: pressed ? 0.7 : 1 }]} accessibilityRole="button"><Feather name="upload" size={17} color={colors.background} /><Text style={[styles.uploadText, { color: colors.background }]}>Upload from camera roll</Text></Pressable>
            <Text style={[styles.privacy, { color: colors.mutedForeground }]}>Only you can see your practice takes.</Text>
          </>
        )}
      </View>
      <View style={[styles.bottomNote, { paddingBottom: insets.bottom + 16 }]}><Feather name="info" size={14} color={colors.mutedForeground} /><Text style={[styles.bottomText, { color: colors.mutedForeground }]}>Match your frame to the official source for the clearest feedback.</Text></View>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  top: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 18 },
  topTitle: { fontSize: 16, fontWeight: '700' },
  iconButton: { width: 40, height: 40, justifyContent: 'center', alignItems: 'center' },
  center: { flex: 1, alignItems: 'center', justifyContent: 'center', paddingHorizontal: 36 },
  cameraGlyph: { width: 92, height: 92, borderRadius: 46, backgroundColor: 'rgba(248,244,238,0.1)', alignItems: 'center', justifyContent: 'center', marginBottom: 22 },
  successCircle: { width: 92, height: 92, borderRadius: 46, alignItems: 'center', justifyContent: 'center', marginBottom: 22 },
  centerTitle: { fontSize: 29, fontWeight: '700', letterSpacing: -0.7 },
  centerBody: { textAlign: 'center', fontSize: 14, lineHeight: 21, marginTop: 10, maxWidth: 295 },
  recordButton: { height: 54, borderRadius: 17, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 10, width: '100%', marginTop: 29 },
  recordDot: { width: 11, height: 11, borderRadius: 6, backgroundColor: '#1B1C2A' },
  recordButtonText: { fontSize: 15, fontWeight: '700' },
  uploadButton: { height: 52, borderRadius: 17, borderWidth: 1, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, width: '100%', marginTop: 10 },
  uploadText: { fontSize: 14, fontWeight: '600' },
  privacy: { fontSize: 11, marginTop: 18 },
  reviewButton: { height: 52, borderRadius: 17, flexDirection: 'row', alignItems: 'center', justifyContent: 'center', gap: 8, width: '100%', marginTop: 29 },
  reviewButtonText: { fontSize: 14, fontWeight: '700' },
  retakeButton: { paddingVertical: 17 },
  retakeText: { fontSize: 13, fontWeight: '600' },
  bottomNote: { paddingHorizontal: 25, flexDirection: 'row', gap: 7, alignItems: 'center' },
  bottomText: { fontSize: 10, lineHeight: 15, flex: 1 },
});