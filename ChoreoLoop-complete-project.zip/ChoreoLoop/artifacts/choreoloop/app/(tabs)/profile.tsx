import AsyncStorage from '@react-native-async-storage/async-storage';
import { Feather, Ionicons } from '@expo/vector-icons';
import { useRouter } from 'expo-router';
import React, { useEffect, useState } from 'react';
import { Pressable, ScrollView, StyleSheet, Text, View } from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

export default function ProfileScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [hasTake, setHasTake] = useState(false);

  useEffect(() => {
    AsyncStorage.getItem('choreoloop.practice').then((value) => setHasTake(Boolean(value && JSON.parse(value).lastTake)));
  }, []);

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView showsVerticalScrollIndicator={false} contentContainerStyle={{ paddingTop: insets.top + 12, paddingBottom: insets.bottom + 106 }}>
        <View style={styles.header}><View><Text style={[styles.eyebrow, { color: colors.primary }]}>YOUR SPACE</Text><Text style={[styles.title, { color: colors.foreground }]}>Progress</Text></View><Pressable style={[styles.settings, { backgroundColor: colors.card }]} accessibilityRole="button" accessibilityLabel="Settings"><Ionicons name="settings-outline" size={20} color={colors.foreground} /></Pressable></View>
        <View style={[styles.profileCard, { backgroundColor: colors.foreground }]}>
          <View style={[styles.profileAvatar, { backgroundColor: colors.primary }]}><Text style={[styles.avatarText, { color: colors.primaryForeground }]}>A</Text></View>
          <View style={{ flex: 1 }}><Text style={[styles.name, { color: colors.background }]}>Alex Rivera</Text><Text style={[styles.handle, { color: colors.mutedForeground }]}>Dancer since 2022</Text></View>
          <Feather name="edit-2" size={16} color={colors.mutedForeground} />
        </View>
        <View style={styles.statsRow}>
          <View style={[styles.stat, { backgroundColor: colors.card, borderColor: colors.border }]}><Text style={[styles.statNumber, { color: colors.primary }]}>03</Text><Text style={[styles.statLabel, { color: colors.mutedForeground }]}>day streak</Text></View>
          <View style={[styles.stat, { backgroundColor: colors.card, borderColor: colors.border }]}><Text style={[styles.statNumber, { color: colors.foreground }]}>12</Text><Text style={[styles.statLabel, { color: colors.mutedForeground }]}>steps learned</Text></View>
          <View style={[styles.stat, { backgroundColor: colors.card, borderColor: colors.border }]}><Text style={[styles.statNumber, { color: colors.foreground }]}>04</Text><Text style={[styles.statLabel, { color: colors.mutedForeground }]}>takes filmed</Text></View>
        </View>
        <Text style={[styles.sectionTitle, { color: colors.foreground }]}>This week</Text>
        <View style={[styles.weekCard, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={styles.weekDays}>{['M', 'T', 'W', 'T', 'F', 'S', 'S'].map((day, index) => <View key={`${day}-${index}`} style={styles.day}><Text style={[styles.dayLabel, { color: colors.mutedForeground }]}>{day}</Text><View style={[styles.dayDot, { backgroundColor: index < 3 ? colors.primary : colors.muted }]}>{index < 3 && <Feather name="check" size={12} color={colors.primaryForeground} />}</View></View>)}</View>
          <View style={[styles.weekFooter, { borderTopColor: colors.border }]}><Text style={[styles.weekText, { color: colors.mutedForeground }]}>You&apos;re building a real habit.</Text><Text style={[styles.weekPercent, { color: colors.primary }]}>43%</Text></View>
        </View>
        <Text style={[styles.sectionTitle, { color: colors.foreground, marginTop: 29 }]}>Practice library</Text>
        <Pressable onPress={() => router.push('/learn')} style={[styles.libraryRow, { backgroundColor: colors.card, borderColor: colors.border }]} accessibilityRole="button"><View style={[styles.libraryIcon, { backgroundColor: colors.accent }]}><Feather name="layers" size={18} color={colors.primary} /></View><View style={{ flex: 1 }}><Text style={[styles.libraryTitle, { color: colors.foreground }]}>Pulse Control</Text><Text style={[styles.libraryMeta, { color: colors.mutedForeground }]}>4 of 8 steps memorized</Text></View><Feather name="chevron-right" size={18} color={colors.mutedForeground} /></Pressable>
        {hasTake ? <View style={[styles.feedbackRow, { backgroundColor: colors.secondary }]}><View style={[styles.feedbackIcon, { backgroundColor: colors.foreground }]}><Feather name="message-circle" size={17} color={colors.background} /></View><View style={{ flex: 1 }}><Text style={[styles.feedbackTitle, { color: colors.foreground }]}>Your movement notes are ready</Text><Text style={[styles.feedbackMeta, { color: colors.mutedForeground }]}>Review your latest take</Text></View><Feather name="arrow-up-right" size={18} color={colors.foreground} /></View> : null}
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { paddingHorizontal: 22, flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginBottom: 22 },
  eyebrow: { fontSize: 11, fontWeight: '800', letterSpacing: 1.3, marginBottom: 5 },
  title: { fontSize: 30, fontWeight: '700', letterSpacing: -0.8 },
  settings: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  profileCard: { marginHorizontal: 22, borderRadius: 20, padding: 17, flexDirection: 'row', alignItems: 'center', gap: 12 },
  profileAvatar: { width: 49, height: 49, borderRadius: 25, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 21, fontWeight: '800' },
  name: { fontSize: 16, fontWeight: '700' },
  handle: { fontSize: 12, marginTop: 3 },
  statsRow: { flexDirection: 'row', gap: 9, marginHorizontal: 22, marginTop: 12 },
  stat: { flex: 1, borderWidth: 1, borderRadius: 16, paddingVertical: 13, paddingHorizontal: 8 },
  statNumber: { fontSize: 23, fontWeight: '700', letterSpacing: -0.7 },
  statLabel: { fontSize: 10, marginTop: 4 },
  sectionTitle: { fontSize: 17, fontWeight: '700', marginHorizontal: 22, marginTop: 28, marginBottom: 11 },
  weekCard: { borderWidth: 1, borderRadius: 18, marginHorizontal: 22, padding: 15 },
  weekDays: { flexDirection: 'row', justifyContent: 'space-between' },
  day: { alignItems: 'center', gap: 8 },
  dayLabel: { fontSize: 10, fontWeight: '600' },
  dayDot: { width: 28, height: 28, borderRadius: 14, alignItems: 'center', justifyContent: 'center' },
  weekFooter: { borderTopWidth: 1, marginTop: 15, paddingTop: 12, flexDirection: 'row', justifyContent: 'space-between' },
  weekText: { fontSize: 11 },
  weekPercent: { fontSize: 12, fontWeight: '700' },
  libraryRow: { borderWidth: 1, borderRadius: 17, marginHorizontal: 22, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 11 },
  libraryIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  libraryTitle: { fontSize: 13, fontWeight: '700' },
  libraryMeta: { fontSize: 11, marginTop: 3 },
  feedbackRow: { borderRadius: 17, marginHorizontal: 22, marginTop: 10, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 11 },
  feedbackIcon: { width: 38, height: 38, borderRadius: 12, alignItems: 'center', justifyContent: 'center' },
  feedbackTitle: { fontSize: 12, fontWeight: '700' },
  feedbackMeta: { fontSize: 11, marginTop: 3 },
});