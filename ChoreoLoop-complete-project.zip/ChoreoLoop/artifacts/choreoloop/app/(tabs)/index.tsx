import AsyncStorage from '@react-native-async-storage/async-storage';
import { Feather, Ionicons } from '@expo/vector-icons';
import { Image } from 'expo-image';
import { LinearGradient } from 'expo-linear-gradient';
import { useRouter } from 'expo-router';
import * as Haptics from 'expo-haptics';
import React, { useEffect, useState } from 'react';
import {
  ImageBackground,
  Pressable,
  ScrollView,
  StyleSheet,
  Text,
  View,
} from 'react-native';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useColors } from '@/hooks/useColors';

const streetCover = require('../../assets/images/cover-street.png');
const contemporaryCover = require('../../assets/images/cover-contemporary.png');

type PracticeState = { completed: boolean; lastTake?: string };

const routines = [
  { id: 'pulse', title: 'Pulse Control', artist: 'Maya J', style: 'Hip-hop', level: 'Intermediate', minutes: 12, cover: streetCover, accent: '#F7D9BF' },
  { id: 'orbit', title: 'Orbit Sequence', artist: 'Noah Lee', style: 'Contemporary', level: 'Beginner', minutes: 9, cover: contemporaryCover, accent: '#DCE5D4' },
];

export default function HomeScreen() {
  const colors = useColors();
  const insets = useSafeAreaInsets();
  const router = useRouter();
  const [practice, setPractice] = useState<PracticeState>({ completed: false });

  useEffect(() => {
    AsyncStorage.getItem('choreoloop.practice').then((value) => {
      if (value) setPractice(JSON.parse(value) as PracticeState);
    });
  }, []);

  const openRoutine = async (id = 'pulse') => {
    await Haptics.selectionAsync();
    router.push({ pathname: '/learn', params: { id } });
  };

  return (
    <View style={[styles.root, { backgroundColor: colors.background }]}>
      <ScrollView
        showsVerticalScrollIndicator={false}
        contentContainerStyle={{ paddingTop: insets.top + 12, paddingBottom: insets.bottom + 108 }}
      >
        <View style={styles.header}>
          <View>
            <Text style={[styles.eyebrow, { color: colors.primary }]}>WEDNESDAY, AUG 07</Text>
            <Text style={[styles.greeting, { color: colors.foreground }]}>Ready to move?</Text>
          </View>
          <Pressable
            testID="profile-button"
            accessibilityRole="button"
            accessibilityLabel="Open profile"
            onPress={() => router.push('/profile')}
            style={({ pressed }) => [styles.avatar, { backgroundColor: colors.foreground, opacity: pressed ? 0.7 : 1 }]}
          >
            <Text style={[styles.avatarText, { color: colors.background }]}>A</Text>
          </Pressable>
        </View>

        <View style={[styles.searchBar, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <Feather name="search" size={18} color={colors.mutedForeground} />
          <Text style={[styles.searchText, { color: colors.mutedForeground }]}>Find a choreography</Text>
          <View style={[styles.searchKey, { backgroundColor: colors.muted }]}>
            <Text style={[styles.searchKeyText, { color: colors.mutedForeground }]}>⌘ K</Text>
          </View>
        </View>

        <View style={styles.sectionHeading}>
          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Continue learning</Text>
            <Text style={[styles.sectionSub, { color: colors.mutedForeground }]}>Pick up where you left off</Text>
          </View>
          <Pressable onPress={() => openRoutine()} accessibilityRole="button">
            <Text style={[styles.linkText, { color: colors.primary }]}>See all</Text>
          </Pressable>
        </View>

        <Pressable
          testID="continue-card"
          onPress={() => openRoutine()}
          style={({ pressed }) => [styles.heroCard, { opacity: pressed ? 0.94 : 1 }]}
        >
          <ImageBackground source={streetCover} style={styles.heroImage} imageStyle={styles.heroImageRadius}>
            <LinearGradient colors={['transparent', 'rgba(21,22,36,0.88)']} style={StyleSheet.absoluteFill} />
            <View style={styles.officialPill}>
              <View style={styles.officialDot} />
              <Text style={styles.officialText}>OFFICIAL CHOREO</Text>
            </View>
            <View style={styles.heroCopy}>
              <Text style={styles.heroKicker}>PULSE CONTROL · 03:42</Text>
              <Text style={styles.heroTitle}>You&apos;re on step 04</Text>
              <View style={styles.progressTrack}><View style={[styles.progressFill, { width: '58%', backgroundColor: colors.primary }]} /></View>
              <View style={styles.heroFooter}>
                <Text style={styles.heroMeta}>58% memorized</Text>
                <View style={styles.resumeButton}><Feather name="play" size={13} color={colors.foreground} /><Text style={[styles.resumeText, { color: colors.foreground }]}>Resume</Text></View>
              </View>
            </View>
          </ImageBackground>
        </Pressable>

        <View style={[styles.streakRow, { backgroundColor: colors.foreground }]}>
          <View style={styles.streakIcon}><Feather name="zap" size={17} color={colors.foreground} /></View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.streakTitle, { color: colors.background }]}>3 day practice streak</Text>
            <Text style={[styles.streakSub, { color: colors.mutedForeground }]}>Keep the rhythm going</Text>
          </View>
          <Text style={[styles.streakCount, { color: colors.primary }]}>03</Text>
        </View>

        <View style={styles.sectionHeading}>
          <View>
            <Text style={[styles.sectionTitle, { color: colors.foreground }]}>Explore routines</Text>
            <Text style={[styles.sectionSub, { color: colors.mutedForeground }]}>Learn from the source</Text>
          </View>
          <Pressable onPress={() => router.push('/profile')} accessibilityRole="button"><Ionicons name="options-outline" size={20} color={colors.foreground} /></Pressable>
        </View>
        <ScrollView horizontal showsHorizontalScrollIndicator={false} contentContainerStyle={styles.routineRow}>
          {routines.map((routine) => (
            <Pressable
              key={routine.id}
              testID={`routine-${routine.id}`}
              onPress={() => openRoutine(routine.id)}
              style={({ pressed }) => [styles.routineCard, { backgroundColor: routine.accent, opacity: pressed ? 0.9 : 1 }]}
            >
              <Image source={routine.cover} style={styles.routineImage} contentFit="cover" />
              <View style={styles.routineCopy}>
                <View style={styles.rowBetween}><Text style={[styles.routineStyle, { color: colors.foreground }]}>{routine.style.toUpperCase()}</Text><Feather name="arrow-up-right" size={16} color={colors.foreground} /></View>
                <Text style={[styles.routineTitle, { color: colors.foreground }]}>{routine.title}</Text>
                <Text style={[styles.routineMeta, { color: colors.foreground }]}>{routine.artist} · {routine.minutes} min</Text>
              </View>
            </Pressable>
          ))}
        </ScrollView>

        <View style={[styles.practiceBanner, { backgroundColor: colors.card, borderColor: colors.border }]}>
          <View style={[styles.bannerIcon, { backgroundColor: colors.accent }]}><Feather name="video" size={20} color={colors.primary} /></View>
          <View style={{ flex: 1 }}>
            <Text style={[styles.bannerTitle, { color: colors.foreground }]}>Ready for a take?</Text>
            <Text style={[styles.bannerText, { color: colors.mutedForeground }]}>Film your version and get notes on your movement.</Text>
          </View>
          <Pressable testID="record-button" onPress={() => router.push('/record')} style={({ pressed }) => [styles.circleButton, { backgroundColor: colors.primary, opacity: pressed ? 0.75 : 1 }]} accessibilityRole="button" accessibilityLabel="Record a take">
            <Feather name="arrow-up-right" size={20} color={colors.primaryForeground} />
          </Pressable>
        </View>
      </ScrollView>
    </View>
  );
}

const styles = StyleSheet.create({
  root: { flex: 1 },
  header: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', paddingHorizontal: 22, marginBottom: 22 },
  eyebrow: { fontSize: 11, fontWeight: '700', letterSpacing: 1.3, marginBottom: 6 },
  greeting: { fontSize: 29, fontWeight: '700', letterSpacing: -0.8 },
  avatar: { width: 42, height: 42, borderRadius: 21, alignItems: 'center', justifyContent: 'center' },
  avatarText: { fontSize: 17, fontWeight: '700' },
  searchBar: { height: 48, borderRadius: 14, borderWidth: 1, marginHorizontal: 22, paddingHorizontal: 15, flexDirection: 'row', alignItems: 'center', gap: 10, marginBottom: 30 },
  searchText: { fontSize: 14, flex: 1 },
  searchKey: { borderRadius: 7, paddingHorizontal: 8, paddingVertical: 4 },
  searchKeyText: { fontSize: 11, fontWeight: '600' },
  sectionHeading: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'flex-end', paddingHorizontal: 22, marginBottom: 13 },
  sectionTitle: { fontSize: 20, fontWeight: '700', letterSpacing: -0.35 },
  sectionSub: { fontSize: 13, marginTop: 4 },
  linkText: { fontSize: 13, fontWeight: '600', marginBottom: 2 },
  heroCard: { height: 260, marginHorizontal: 22, marginBottom: 16, borderRadius: 22, overflow: 'hidden' },
  heroImage: { flex: 1, justifyContent: 'space-between' },
  heroImageRadius: { borderRadius: 22 },
  officialPill: { flexDirection: 'row', alignItems: 'center', alignSelf: 'flex-start', backgroundColor: 'rgba(248,244,238,0.92)', borderRadius: 20, paddingHorizontal: 10, paddingVertical: 6, margin: 14, gap: 6 },
  officialDot: { width: 6, height: 6, borderRadius: 3, backgroundColor: '#EF5B4F' },
  officialText: { color: '#1B1C2A', fontSize: 9, fontWeight: '800', letterSpacing: 1 },
  heroCopy: { padding: 17 },
  heroKicker: { color: '#F7D9BF', fontSize: 10, fontWeight: '700', letterSpacing: 1.1, marginBottom: 6 },
  heroTitle: { color: '#FFFFFF', fontSize: 24, fontWeight: '700', letterSpacing: -0.6, marginBottom: 12 },
  progressTrack: { height: 4, backgroundColor: 'rgba(255,255,255,0.3)', borderRadius: 2, overflow: 'hidden' },
  progressFill: { height: 4, borderRadius: 2 },
  heroFooter: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center', marginTop: 10 },
  heroMeta: { color: '#FFFFFF', fontSize: 12, fontWeight: '500' },
  resumeButton: { borderRadius: 16, backgroundColor: '#F8F4EE', flexDirection: 'row', alignItems: 'center', gap: 5, paddingHorizontal: 11, paddingVertical: 7 },
  resumeText: { fontSize: 11, fontWeight: '700' },
  streakRow: { marginHorizontal: 22, borderRadius: 18, padding: 13, flexDirection: 'row', alignItems: 'center', gap: 11, marginBottom: 31 },
  streakIcon: { width: 34, height: 34, borderRadius: 17, backgroundColor: '#F7D9BF', alignItems: 'center', justifyContent: 'center' },
  streakTitle: { fontSize: 13, fontWeight: '700' },
  streakSub: { fontSize: 11, marginTop: 3 },
  streakCount: { fontSize: 23, fontWeight: '700', letterSpacing: -1 },
  routineRow: { paddingHorizontal: 22, gap: 13, paddingBottom: 8 },
  routineCard: { width: 198, borderRadius: 20, overflow: 'hidden' },
  routineImage: { width: '100%', height: 152 },
  routineCopy: { padding: 13 },
  rowBetween: { flexDirection: 'row', justifyContent: 'space-between', alignItems: 'center' },
  routineStyle: { fontSize: 9, fontWeight: '800', letterSpacing: 1 },
  routineTitle: { fontSize: 20, fontWeight: '700', marginTop: 6, letterSpacing: -0.5 },
  routineMeta: { opacity: 0.7, fontSize: 11, marginTop: 6, fontWeight: '500' },
  practiceBanner: { marginHorizontal: 22, marginTop: 28, borderWidth: 1, borderRadius: 19, padding: 14, flexDirection: 'row', alignItems: 'center', gap: 11 },
  bannerIcon: { width: 40, height: 40, borderRadius: 13, alignItems: 'center', justifyContent: 'center' },
  bannerTitle: { fontSize: 14, fontWeight: '700' },
  bannerText: { fontSize: 11, lineHeight: 16, marginTop: 3, paddingRight: 4 },
  circleButton: { width: 40, height: 40, borderRadius: 20, alignItems: 'center', justifyContent: 'center' },
});
