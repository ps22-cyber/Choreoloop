import { useEffect, useRef, useState, type ChangeEvent, type Dispatch, type ReactNode, type SetStateAction } from 'react';
import { QueryClient, QueryClientProvider } from '@tanstack/react-query';
import { ErrorBoundary } from '@/components/error-boundary';
import { Toaster } from '@/components/ui/toaster';
import { TooltipProvider } from '@/components/ui/tooltip';
import NotFound from '@/pages/not-found';
import {
  Activity,
  ArrowRight,
  Award,
  CalendarDays,
  Camera,
  Check,
  ChevronRight,
  CircleHelp,
  Disc3,
  Eye,
  FileVideo,
  Home as HomeIcon,
  LibraryBig,
  Pause,
  Play,
  RotateCcw,
  Sparkles,
  Target,
  Upload,
  Video,
  WandSparkles,
  X,
} from 'lucide-react';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import coverStreet from '@/assets/images/cover-street.png';
import coverContemporary from '@/assets/images/cover-contemporary.png';
import brandMark from '@/assets/images/icon.png';

const queryClient = new QueryClient();

type Routine = {
  id: string;
  title: string;
  artist: string;
  style: string;
  duration: string;
  level: string;
  image: string;
  progress: number;
};

type Step = { id: number; title: string; time: string; detail: string };

const routines: Routine[] = [
  { id: 'afterglow', title: 'Afterglow', artist: 'Mira Vale', style: 'Open style', duration: '2:48', level: 'Intermediate', image: coverStreet, progress: 62 },
  { id: 'soft-focus', title: 'Soft Focus', artist: 'Iris Theory', style: 'Contemporary', duration: '3:12', level: 'Beginner', image: coverContemporary, progress: 34 },
  { id: 'low-key', title: 'Low Key', artist: 'North Arcade', style: 'Groove', duration: '2:21', level: 'Intermediate', image: coverStreet, progress: 18 },
];

const steps: Step[] = [
  { id: 1, title: 'The lean + reach', time: '00:14', detail: 'Anchor the standing foot, then let your ribs lead the reach.' },
  { id: 2, title: 'Cross step groove', time: '00:28', detail: 'Keep the cross light and let the heel arrive one count late.' },
  { id: 3, title: 'Drop & rebound', time: '00:41', detail: 'Drop through the knees before the chest catches the beat.' },
  { id: 4, title: 'The orbit', time: '00:57', detail: 'Draw a wide circle with the arm while your weight stays low.' },
  { id: 5, title: 'Final picture', time: '01:12', detail: 'Hold the shape for a breath. Make the ending feel intentional.' },
];

type ProgressState = {
  sessions: number;
  minutes: number;
  afterglow: number;
  softFocus: number;
  lowKey: number;
  takeCount: number;
};

const defaultProgress: ProgressState = {
  sessions: 7,
  minutes: 86,
  afterglow: 62,
  softFocus: 34,
  lowKey: 18,
  takeCount: 2,
};

function readProgress(): ProgressState {
  try {
    const saved = localStorage.getItem('choreoloop-progress');
    return saved ? { ...defaultProgress, ...JSON.parse(saved) } : defaultProgress;
  } catch {
    return defaultProgress;
  }
}

function AppShell({ children, active, onNavigate }: {
  children: ReactNode;
  active: string;
  onNavigate: (path: string) => void;
}) {
  const navItems = [
    { path: '/', label: 'Home', icon: HomeIcon },
    { path: '/learn', label: 'Learn', icon: LibraryBig },
    { path: '/record', label: 'Record', icon: Video },
    { path: '/progress', label: 'Progress', icon: Activity },
  ];
  return (
    <div className="app-shell">
      <aside className="sidebar">
        <button className="brand" onClick={() => onNavigate('/')} data-testid="button-brand-home">
          <img className="brand-mark" src={brandMark} alt="ChoreoLoop mark" />
          <span className="brand-word">choreo<span>loop</span></span>
        </button>
        <div className="nav-label">Studio</div>
        <nav className="nav-stack" aria-label="Main navigation">
          {navItems.map(({ path, label, icon: Icon }) => (
            <button
              key={path}
              className={`nav-item ${active === path ? 'active' : ''}`}
              onClick={() => onNavigate(path)}
              data-testid={`button-nav-${label.toLowerCase()}`}
            >
              <Icon />
              <span>{label}</span>
            </button>
          ))}
        </nav>
        <div className="sidebar-bottom">
          <div className="streak-card">
            <div className="streak-top"><span>Practice rhythm</span><Sparkles size={14} color="#f5d681" /></div>
            <div className="streak-value"><strong>04</strong><small>days in a row</small></div>
            <div className="streak-bar"><span /></div>
          </div>
          <div className="profile">
            <div className="avatar">AM</div>
            <div><p>Alex Morgan</p><small>Intermediate dancer</small></div>
          </div>
        </div>
      </aside>
      <main className="main-area">
        <header className="topbar">
          <div className="eyebrow"><span className="eyebrow-dot" /> personal studio <span>/</span> 2024</div>
          <div className="top-actions">
            <button className="icon-button" title="Help and shortcuts" data-testid="button-help"><CircleHelp size={16} /></button>
            <button className="icon-button" title="Reset practice rhythm" onClick={() => onNavigate('/progress')} data-testid="button-open-progress"><Award size={16} /></button>
          </div>
        </header>
        {children}
      </main>
      <nav className="mobile-nav" aria-label="Mobile navigation">
        {navItems.map(({ path, label, icon: Icon }) => (
          <button key={path} className={`nav-item ${active === path ? 'active' : ''}`} onClick={() => onNavigate(path)} data-testid={`button-mobile-nav-${label.toLowerCase()}`}>
            <Icon /><span>{label}</span>
          </button>
        ))}
      </nav>
    </div>
  );
}

function Header({ kicker, title, description, action }: { kicker: string; title: ReactNode; description: string; action?: ReactNode }) {
  return (
    <div className="welcome-row">
      <div>
        <div className="panel-kicker">{kicker}</div>
        <h1 className="page-title">{title}</h1>
        <p className="page-subtitle">{description}</p>
      </div>
      {action || <div className="date-chip"><CalendarDays size={14} /> Tuesday, April 16</div>}
    </div>
  );
}

function HomePage({ onChoose }: { onChoose: (routine: Routine) => void }) {
  return (
    <div className="content">
      <Header
        kicker="Welcome back, Alex"
        title={<>Make room for <em>movement.</em></>}
        description="Your studio is ready. Pick up where you left off, or follow the beat somewhere new."
      />
      <section className="hero-card">
        <div className="hero-copy">
          <div className="hero-kicker">Continue your session · 04 of 05</div>
          <h2 className="hero-title">Afterglow is starting to click.</h2>
          <p>You are one clean run away from locking in the orbit. Let’s work the transition slowly, then let it breathe.</p>
          <button className="hero-cta" onClick={() => onChoose(routines[0])} data-testid="button-continue-afterglow">Continue practice <ArrowRight size={15} /></button>
        </div>
        <div className="hero-image">
          <img src={coverStreet} alt="Dancer leaning into a movement in a sunlit studio" />
          <div className="hero-stamp">MOVE<br />WITH<br />INTENT</div>
        </div>
      </section>

      <div className="section-head">
        <div><h2 className="section-title">Your routines</h2><p className="section-note">Small sessions add up. Choose the feeling for today.</p></div>
        <button className="text-button" onClick={() => onChoose(routines[1])} data-testid="button-browse-routines">Browse all <ChevronRight size={13} style={{ verticalAlign: 'middle' }} /></button>
      </div>
      <div className="routine-grid">
        {routines.map((routine, index) => (
          <button className="routine-card" key={routine.id} onClick={() => onChoose(routine)} data-testid={`card-routine-${routine.id}`}>
            <img src={routine.image} alt="" />
            <span className="routine-arrow"><ArrowRight size={14} /></span>
            <div className="routine-info">
              <div className="routine-type">{index === 0 ? 'In progress' : routine.style}</div>
              <div className="routine-name">{routine.title}</div>
              <div className="routine-meta">{routine.artist} · {routine.duration} · {routine.level}</div>
            </div>
          </button>
        ))}
      </div>
      <div className="section-head">
        <div><h2 className="section-title">A note for your body</h2><p className="section-note">Before the next take: soften your shoulders and notice the floor.</p></div>
      </div>
    </div>
  );
}

function LearnPage({ routine, onProgress }: { routine: Routine; onProgress: (step: number) => void }) {
  const [selectedStep, setSelectedStep] = useState(1);
  const [cuesOn, setCuesOn] = useState(true);
  const [playing, setPlaying] = useState(false);
  const currentStep = steps[selectedStep - 1];
  const progressValue = Math.min(100, routine.progress + (selectedStep - 1) * 4);
  return (
    <div className="content">
      <Header
        kicker={`Learn / ${routine.style}`}
        title={<>Find the <em>groove.</em></>}
        description={`A considered breakdown for ${routine.title} by ${routine.artist}. Take the pressure off, then put the rhythm back in.`}
        action={<button className="date-chip" onClick={() => setCuesOn((value) => !value)} data-testid="button-toggle-cues-top"><WandSparkles size={14} /> {cuesOn ? 'Cues on' : 'Cues off'}</button>}
      />
      <div className="practice-layout">
        <section className="panel video-panel">
          <div className="video-head">
            <div className="video-title">{routine.title} <span style={{ color: '#8390a6', fontWeight: 400 }}>· choreography view</span></div>
            <div className="video-status"><span /> guided breakdown</div>
          </div>
          <div className="stage">
            <img src={routine.image} alt={`${routine.title} choreography demonstration`} />
            <div className="stage-overlay" />
            {cuesOn && <div className="cue-badge"><Eye size={14} /> visual cues active</div>}
            <div className="stage-controls">
              <button className="play-button" onClick={() => setPlaying((value) => !value)} title={playing ? 'Pause choreography' : 'Play choreography'} data-testid="button-play-choreography">
                {playing ? <Pause size={17} fill="currentColor" /> : <Play size={17} fill="currentColor" />}
              </button>
              <div className="timeline" aria-label="Video progress"><span /></div>
              <span className="time-text">{currentStep.time} / 01:28</span>
            </div>
          </div>
        </section>
        <aside className="panel steps-panel">
          <div className="panel-kicker">Break it down</div>
          <h2 className="steps-title">{routine.title}</h2>
          <p className="steps-subtitle">{currentStep.detail}</p>
          <div className="step-list">
            {steps.map((step) => (
              <button key={step.id} className={`step-button ${selectedStep === step.id ? 'active' : ''}`} onClick={() => { setSelectedStep(step.id); onProgress(step.id); }} data-testid={`button-step-${step.id}`}>
                <span className="step-number">{selectedStep > step.id ? <Check size={13} /> : `0${step.id}`}</span>
                <span className="step-name">{step.title}</span>
                <span className="step-count">{step.time}</span>
              </button>
            ))}
          </div>
          <div className="controls-row">
            <div className="toggle-wrap"><button className={`toggle ${cuesOn ? 'on' : ''}`} onClick={() => setCuesOn((value) => !value)} aria-label="Toggle visual cues" data-testid="button-toggle-visual-cues"><span /></button> visual cues</div>
            <button className="primary-button" onClick={() => { setSelectedStep((value) => Math.min(5, value + 1)); onProgress(Math.min(5, selectedStep + 1)); }} data-testid="button-next-step">Next step <ArrowRight size={13} /></button>
          </div>
        </aside>
      </div>
      <div className="section-head">
        <div><h2 className="section-title">Session markers</h2><p className="section-note">You are {progressValue}% through this routine. Keep the quality high.</p></div>
        <div className="date-chip"><Target size={14} /> step {selectedStep} of 05</div>
      </div>
    </div>
  );
}

function RecordPage({ onProgress, takeCount }: { onProgress: () => void; takeCount: number }) {
  const [recording, setRecording] = useState(false);
  const [elapsed, setElapsed] = useState(0);
  const [notice, setNotice] = useState('Camera access stays in your browser. Nothing leaves this device.');
  const [recorded, setRecorded] = useState<Blob | null>(null);
  const [uploadedName, setUploadedName] = useState('');
  const recorderRef = useRef<MediaRecorder | null>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const chunksRef = useRef<Blob[]>([]);
  const timerRef = useRef<number | null>(null);

  useEffect(() => () => {
    if (timerRef.current) window.clearInterval(timerRef.current);
    streamRef.current?.getTracks().forEach((track) => track.stop());
  }, []);

  const beginRecording = async () => {
    if (recording) {
      recorderRef.current?.stop();
      return;
    }
    if (!navigator.mediaDevices?.getUserMedia || !window.MediaRecorder) {
      setNotice('Live recording is not supported in this browser. Upload a video file below to review a take.');
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getUserMedia({ video: true, audio: true });
      streamRef.current = stream;
      chunksRef.current = [];
      const recorder = new MediaRecorder(stream);
      recorderRef.current = recorder;
      recorder.ondataavailable = (event) => { if (event.data.size > 0) chunksRef.current.push(event.data); };
      recorder.onstop = () => {
        setRecorded(new Blob(chunksRef.current, { type: recorder.mimeType || 'video/webm' }));
        setRecording(false);
        stream.getTracks().forEach((track) => track.stop());
        if (timerRef.current) window.clearInterval(timerRef.current);
        setNotice('Take saved locally. Review it when you are ready, then record another angle.');
        onProgress();
      };
      recorder.start();
      setElapsed(0);
      setRecording(true);
      setNotice('Recording live. Find the groove, not perfection.');
      timerRef.current = window.setInterval(() => setElapsed((value) => value + 1), 1000);
    } catch {
      setNotice('Camera access was unavailable. You can still upload a take below, or check browser permissions and try again.');
    }
  };

  const handleUpload = (event: ChangeEvent<HTMLInputElement>) => {
    const file = event.target.files?.[0];
    if (!file) return;
    setUploadedName(file.name);
    setNotice('Upload ready for review. This file stays local to your session.');
    onProgress();
  };

  const elapsedLabel = `${String(Math.floor(elapsed / 60)).padStart(2, '0')}:${String(elapsed % 60).padStart(2, '0')}`;
  return (
    <div className="content">
      <Header kicker="Record / your perspective" title={<>Make a <em>take.</em></>} description="Put the guide away for a minute. Your body knows more than it thinks it does." />
      <div className="record-layout">
        <section className="record-panel">
          <div className="video-head"><div className="video-title">Practice camera</div><div className="video-status"><span className={recording ? 'record-dot live' : 'record-dot'} /> {recording ? 'recording' : 'ready to record'}</div></div>
          <div className="record-stage">
            <div className="record-center">
              <div className="record-ring"><Camera /></div>
              <p>{recording ? 'You are in it.' : recorded ? 'Take captured.' : 'The floor is yours.'}</p>
              <small>{recording ? elapsedLabel : recorded ? 'Ready for a review' : 'Use your camera or upload a take'}</small>
            </div>
          </div>
          <div className="record-bar">
            <div><span className={`record-dot ${recording ? 'live' : ''}`} /><span className="record-time">{recording ? elapsedLabel : `${takeCount} takes this month`}</span></div>
            <button className="primary-button" onClick={beginRecording} data-testid="button-toggle-recording">{recording ? <><X size={14} /> Finish take</> : <><Disc3 size={14} /> Start recording</>}</button>
          </div>
        </section>
        <aside className="panel record-info">
          <div className="panel-kicker">Your studio archive</div>
          <h2>Review the way you move.</h2>
          <p>Compare your take with the guidance, notice one useful detail, then try again. Progress lives in the noticing.</p>
          <label className="dropzone" htmlFor="take-upload" data-testid="label-upload-take">
            <Upload size={17} color="#f25c54" />
            <strong>{uploadedName || 'Bring in a take'}</strong>
            <span>{uploadedName ? 'Ready to review locally' : 'MP4, WebM or MOV · up to 200 MB'}</span>
          </label>
          <input id="take-upload" type="file" accept="video/*" onChange={handleUpload} data-testid="input-upload-take" style={{ display: 'none' }} />
          <div className="button-row">
            <label className="secondary-button" htmlFor="take-upload"><FileVideo size={14} /> Choose video</label>
            {recorded && <button className="secondary-button" onClick={() => { setRecorded(null); setNotice('Take cleared. Ready for another one.'); }} data-testid="button-clear-take"><RotateCcw size={14} /> Clear take</button>}
          </div>
          <div className="notice"><Check size={13} /> <span>{notice}</span></div>
        </aside>
      </div>
    </div>
  );
}

function ProgressPage({ progress, onReset }: { progress: ProgressState; onReset: () => void }) {
  const bars = [42, 58, 46, 73, 63, Math.min(95, 63 + progress.sessions)];
  const routineProgress = [
    { routine: routines[0], value: progress.afterglow },
    { routine: routines[1], value: progress.softFocus },
    { routine: routines[2], value: progress.lowKey },
  ];
  return (
    <div className="content">
      <Header kicker="Progress / the long view" title={<>Notice your <em>practice.</em></>} description="A little evidence that the work is happening, even on the days it feels quiet." action={<button className="date-chip" onClick={onReset} data-testid="button-reset-progress"><RotateCcw size={13} /> Reset view</button>} />
      <div className="progress-grid">
        <section className="panel stat-panel">
          <div className="panel-kicker">This week</div>
          <div className="stat-big">{progress.minutes}<span style={{ fontSize: 18, letterSpacing: '-.02em' }}> min</span></div>
          <div className="stat-caption">{progress.sessions} sessions · {progress.takeCount} recorded takes</div>
          <div className="mini-bars">
            {bars.map((value, index) => <div className="bar-column" key={index}><div className={`bar ${index === 5 ? 'current' : ''}`} style={{ height: `${value}%` }} /><label>{['M', 'T', 'W', 'T', 'F', 'S'][index]}</label></div>)}
          </div>
        </section>
        <section className="panel progress-list">
          <div className="panel-kicker">Routine library</div>
          <div className="section-head" style={{ margin: '7px 0 3px' }}><div><h2 className="steps-title">What is staying with you</h2></div><Award size={22} color="#f25c54" /></div>
          {routineProgress.map(({ routine, value }) => (
            <div className="progress-row" key={routine.id} data-testid={`row-progress-${routine.id}`}>
              <img className="progress-thumb" src={routine.image} alt="" />
              <div><div className="progress-name">{routine.title}</div><div className="progress-meta">{routine.artist} · {routine.level}</div><div className="meter"><span style={{ width: `${value}%` }} /></div></div>
              <div className="progress-percent">{value}%</div>
            </div>
          ))}
        </section>
      </div>
      <div className="section-head">
        <div><h2 className="section-title">A useful metric</h2><p className="section-note">Consistency is a shape, not a score. Keep showing up.</p></div>
      </div>
      <div className="panel stat-panel" style={{ display: 'flex', alignItems: 'center', gap: 18, background: '#b7e7dc' }}>
        <Target size={28} color="#16233f" />
        <div><strong style={{ fontFamily: 'var(--font-display)', fontSize: 18 }}>Your strongest session: Tuesday, 18 minutes.</strong><div style={{ fontSize: 11, marginTop: 4, color: '#526e70' }}>You repeated one transition six times. That is how vocabulary becomes instinct.</div></div>
      </div>
    </div>
  );
}

function RouterContent({ progress, setProgress, routine, setRoutine }: {
  progress: ProgressState;
  setProgress: Dispatch<SetStateAction<ProgressState>>;
  routine: Routine;
  setRoutine: (routine: Routine) => void;
}) {
  const [location, setLocation] = useLocation();
  const activePath = location.endsWith('/learn') ? '/learn' : location.endsWith('/record') ? '/record' : location.endsWith('/progress') ? '/progress' : '/';
  const navigate = (path: string) => setLocation(path);
  const updatePractice = (step: number) => {
    setProgress((current) => {
      const next = { ...current, sessions: Math.max(current.sessions, step > 1 ? current.sessions + 1 : current.sessions), minutes: current.minutes + (step === 5 ? 3 : 0), afterglow: Math.min(100, Math.max(current.afterglow, 56 + step * 4)) };
      localStorage.setItem('choreoloop-progress', JSON.stringify(next));
      return next;
    });
  };
  const updateTake = () => {
    setProgress((current) => {
      const next = { ...current, takeCount: current.takeCount + 1, sessions: current.sessions + 1, minutes: current.minutes + 4 };
      localStorage.setItem('choreoloop-progress', JSON.stringify(next));
      return next;
    });
  };
  return (
    <AppShell active={activePath} onNavigate={navigate}>
      <Switch>
        <Route path="/learn"><LearnPage routine={routine} onProgress={updatePractice} /></Route>
        <Route path="/record"><RecordPage onProgress={updateTake} takeCount={progress.takeCount} /></Route>
        <Route path="/progress"><ProgressPage progress={progress} onReset={() => { localStorage.removeItem('choreoloop-progress'); setProgress(defaultProgress); }} /></Route>
        <Route path="/" ><HomePage onChoose={(chosen) => { setRoutine(chosen); navigate('/learn'); }} /></Route>
        <Route component={NotFound} />
      </Switch>
    </AppShell>
  );
}

function RoutedErrorBoundary({ children }: { children: ReactNode }) {
  const [location] = useLocation();
  return <ErrorBoundary resetKey={location}>{children}</ErrorBoundary>;
}

function App() {
  const [progress, setProgress] = useState<ProgressState>(defaultProgress);
  const [routine, setRoutine] = useState<Routine>(routines[0]);
  const [ready, setReady] = useState(false);
  useEffect(() => {
    setProgress(readProgress());
    const timer = window.setTimeout(() => setReady(true), 220);
    return () => window.clearTimeout(timer);
  }, []);
  if (!ready) return <div className="app-shell" style={{ alignItems: 'center', justifyContent: 'center' }}><div className="panel stat-panel" style={{ width: 290 }}><div className="panel-kicker">Loading your studio</div><div style={{ height: 10, background: '#e5ded4', borderRadius: 8, marginTop: 18 }} /><div style={{ height: 10, width: '72%', background: '#e5ded4', borderRadius: 8, marginTop: 10 }} /></div></div>;
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/, '')}>
          <RoutedErrorBoundary><RouterContent progress={progress} setProgress={setProgress} routine={routine} setRoutine={setRoutine} /></RoutedErrorBoundary>
        </WouterRouter>
        <Toaster />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;